const { uploadFileToSpaces, uploadMultipleFilesToSpaces } = require('../services/s3Service.js');
const FileUpload = require("../models/fileModel");


const uploadSingleFile = async (req, res) => {
  try {
    const file = req.file;
console.log("Decoded user:", req.user);

    if (!file) {
      return res.status(400).json({ message: "No file uploaded!" });
    }

    const fileUrl = await uploadFileToSpaces(file);

    // ✅ Database me save karna
    const savedFile = await FileUpload.create({
      fileName: file.originalname,   // ✅ Required field
      fileUrl: fileUrl,      // ✅ Uploaded URL
  uploadedBy: req.user._id || req.user.id,   // ✅ User ID
        uploadedByEmail: req.user.email   // ✅ correct field name
    });

    return res.status(200).json({
      message: "File uploaded successfully!",
      data: savedFile
    });

  } catch (error) {
    console.log("Upload Single File Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};


const uploadMultipleFiles = async (req, res) => {
  try {
    const files = req.files;

    if (!files || files.length === 0) {
      return res.status(400).json({ message: "No files uploaded!" });
    }

    const urls = await uploadMultipleFilesToSpaces(files);

    return res.status(200).json({
      message: "Files uploaded successfully!",
      urls,
    });
  } catch (error) {
    console.log("Upload Multiple File Error:", error);
    return res.status(500).json({ message: "Internal Server Error" });
  }
};



const getAllFilesForAdmin = async (req, res) => {
  try {
    // Query params
    const { page = 1, limit = 20, userId, search } = req.query;
    const skip = (parseInt(page) - 1) * parseInt(limit);

    // Base filter
    const filter = {};
    if (userId) filter.uploadedBy = userId;
    if (search) {
      // simple fileName search (case-insensitive)
      filter.fileName = { $regex: search, $options: "i" };
    }

    // Count total
    const total = await FileUpload.countDocuments(filter);

    // Fetch with populate
    const files = await FileUpload.find(filter)
      .populate("uploadedBy", "fullName email phone") // show only required user fields
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    return res.status(200).json({
      message: "Files fetched successfully",
      total,
      page: parseInt(page),
      limit: parseInt(limit),
      files,
    });
  } catch (error) {
    console.error("Error fetching files for admin:", error);
    return res.status(500).json({ message: "Server error" });
  }
};



module.exports = {
  uploadSingleFile,
  uploadMultipleFiles,
    getAllFilesForAdmin
};
