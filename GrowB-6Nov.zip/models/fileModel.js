// const mongoose = require("mongoose");

// const fileSchema = new mongoose.Schema(
//   {
//     originalName: {
//       type: String,
//       required: true,
//     },
//     fileName: {
//       type: String,
//       required: true,
//     },
//     fileUrl: {
//       type: String,
//       required: true,
//     },
//     mimeType: {
//       type: String,
//       required: true,
//     },
//     size: {
//       type: Number,
//       required: true,
//     },
    // uploadedBy: {
    //   type: mongoose.Schema.Types.ObjectId,
    //   ref: "User", // Admin ya user dono ho sakte
    //   default: null,
    // },
//   },
//   { timestamps: true }
// );

// module.exports = mongoose.model("FileUpload", fileSchema);


// const mongoose = require("mongoose");

// const FileUploadSchema = new mongoose.Schema({
//   fileName: {
//     type: String,
//     required: true
//   },
//   fileUrl: {
//     type: String,
//     required: true
//   },
//   createdAt: {
//     type: Date,
//     default: Date.now
//   }
// });

// module.exports = mongoose.model("FileUpload", FileUploadSchema);


const mongoose = require("mongoose");

const FileUploadSchema = new mongoose.Schema({
  fileName: {
    type: String,
    required: true
  },
  fileUrl: {
    type: String,
    required: true
  },

  uploadedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true
  },

    amount: { type: Number, default: 0 }, // new
  approved: { type: Boolean, default: false }, // new

  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model("FileUpload", FileUploadSchema);
