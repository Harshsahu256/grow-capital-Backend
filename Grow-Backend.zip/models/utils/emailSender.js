// const nodemailer = require("nodemailer");
// require("dotenv").config(); // Load environment variables

// const sendEmail = async (to, subject, htmlContent) => {
//   try {
//     // 1. Create a Nodemailer transporter
//     //    Configure with your SMTP service details.
//     //    For testing, you can use ethereal.email or a real service like Gmail.
//     //    If using Gmail, enable "Less secure app access" or use an App Password.
//     const transporter = nodemailer.createTransport({
//       host: process.env.EMAIL_HOST, // e.g., 'smtp.gmail.com'
//       port: process.env.EMAIL_PORT, // e.g., 587 (for TLS) or 465 (for SSL)
//       secure: process.env.EMAIL_SECURE === 'true', // true for 465, false for other ports
//       auth: {
//         user: process.env.EMAIL_USER,     // Your email address
//         pass: process.env.EMAIL_PASS,     // Your email password or App Password
//       },
//     });

//     // 2. Define email options
//     const mailOptions = {
//       from: process.env.EMAIL_USER, // Sender address
//       to: to,                      // List of receivers
//       subject: subject,            // Subject line
//       html: htmlContent,           // HTML body
//     };

//     // 3. Send the email
//     const info = await transporter.sendMail(mailOptions);
//     console.log("Message sent: %s", info.messageId);
//     console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info)); // Only for Ethereal
//     return true;
//   } catch (error) {
//     console.error("Error sending email:", error);
//     return false;
//   }
// };

// module.exports = sendEmail;

// const nodemailer = require("nodemailer");
// require("dotenv").config();

// const sendEmail = async (to, subject, htmlContent) => {
//   try {
//     const transporter = nodemailer.createTransport({
//       host: process.env.EMAIL_HOST,
//       port: process.env.EMAIL_PORT,
//       secure: process.env.EMAIL_SECURE === "true", // TLS false, SSL true
//       auth: {
//         user: process.env.EMAIL_USER,
//         pass: process.env.EMAIL_PASS,
//       },
//     });

//     const mailOptions = {
//       from: `"GrowAdmin" <${process.env.EMAIL_USER}>`, // sender name + email
//       to,
//       subject,
//       html: htmlContent,
//     };

//     const info = await transporter.sendMail(mailOptions);
//     console.log("✅ Email sent:", info.messageId);
//     return true;
//   } catch (error) {
//     console.error("❌ Error sending email:", error);
//     return false;
//   }
// };

// module.exports = sendEmail;


// utils/sendEmail.js
const nodemailer = require("nodemailer");
require("dotenv").config(); // Load .env variables

/**
 * sendEmail - Function to send emails via SMTP
 * @param {string} to - Recipient email address
 * @param {string} subject - Email subject line
 * @param {string} htmlContent - HTML content of the email
 * @returns {boolean} - true if email sent successfully, false otherwise
 */
const sendEmail = async (to, subject, htmlContent) => {
  try {
    // 1️⃣ Create transporter
    const transporter = nodemailer.createTransport({
      host: process.env.EMAIL_HOST,           // e.g., smtp.gmail.com
      port: parseInt(process.env.EMAIL_PORT), // 587 for TLS, 465 for SSL
      secure: process.env.EMAIL_SECURE === "true", // true = SSL, false = TLS
      auth: {
        user: process.env.EMAIL_USER,         // Sender Gmail address
        pass: process.env.EMAIL_PASS,         // Gmail App Password
      },
    });

    // 2️⃣ Define mail options
    const mailOptions = {
      from: `"GrowAdmin" <${process.env.EMAIL_USER}>`, // Display name + email
      to,                     // Recipient email
      subject,                // Subject line
      html: htmlContent,      // HTML body
    };

    // 3️⃣ Send the email
    const info = await transporter.sendMail(mailOptions);

    console.log("✅ Email sent:", info.messageId);
    if (process.env.NODE_ENV !== "production") {
      console.log("Preview URL:", nodemailer.getTestMessageUrl(info)); // Only for Ethereal
    }

    return true;
  } catch (error) {
    console.error("❌ Error sending email:", error);
    return false;
  }
};

module.exports = sendEmail;


